<?php if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true)die();?>

<div class="header__social header-social">
    <div class="header-social__wrap">
        <a href="<?= $arParams['LINK_VK'] ?>" class="header-social__link -vk" target="_blank"></a>
        <a href="<?= $arParams['LINK_INSTAGRAM'] ?>" class="header-social__link -inst"
           target="_blank"></a>
        <a href="<?= $arParams['LINK_YOUTUBE'] ?>"
           class="header-social__link -youtube" target="_blank"></a>
    </div>
</div>