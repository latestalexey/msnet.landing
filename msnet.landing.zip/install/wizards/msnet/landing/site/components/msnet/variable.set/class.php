<?php

class VariableSet extends CBitrixComponent
{
	public function executeComponent ()
	{
		$this->includeComponentTemplate();
	}
}