<?php if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true)die();?>
<?=IncludeTemplateLangFile(__FILE__)?>
<div class="m-about" id="about">
    <h2><?=GetMessage('ABOUT_TITLE')?></h2>
    <div class="m-about__text">
        <p>
            <?=GetMessage('ABOUT_P1')?>
        </p>
        <p>
            <?=GetMessage('ABOUT_P2')?>
        </p>
    </div>
</div>