<?php if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true)die();?>

<div class="footer__social footer-social">
    <div class="footer-social__title">Группа в соцсетях:</div>
    <a href="<?= $arParams['LINK_VK'] ?>" class="footer-social__link -vk" target="_blank"></a>
    <a href="<?= $arParams['LINK_INSTAGRAM'] ?>" class="footer-social__link -inst"
       target="_blank"></a>
    <a href="<?= $arParams['LINK_YOUTUBE'] ?>"
       class="footer-social__link -youtube" target="_blank"></a>
</div>