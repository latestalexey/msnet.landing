<?php
$MESS =
    [
        "FOOTER_CONTACTS" => "Организация концертов музыкальной группы +7 (900) 123 45 67 Светлана Смирнова",
        "FOOTER_COPYRIGHT" => "&copy;" . date('Y', time()) . " Все права защищены.",
        "FOOTER_SOC_TITLE" => "Группа в соцсетях:",
    ];