<?
$MESS['CT_BNL_ELEMENT_DELETE_CONFIRM'] = 'Будет удалена вся информация, связанная с этой записью. Продолжить?';
$MESS["C_BLOCK_TITLE"] = "Ближайшие концерты";
$MESS["C_BLOCK_BUY"] = "Купить билет";
?>