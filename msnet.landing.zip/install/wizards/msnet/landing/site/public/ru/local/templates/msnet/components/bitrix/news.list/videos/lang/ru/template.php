<?
$MESS["V_BLOCK_TITLE"] = "Видео";
?>