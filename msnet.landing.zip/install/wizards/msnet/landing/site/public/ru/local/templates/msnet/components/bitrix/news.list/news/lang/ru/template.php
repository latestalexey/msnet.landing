<?
$MESS["N_BLOCK_TITLE"] = "Новости";
?>