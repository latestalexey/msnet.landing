<div class="m-banner__title">
Концертный тур<br>музыкальной группы
</div>