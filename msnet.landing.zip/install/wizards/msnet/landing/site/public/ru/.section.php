<?
$sSectionName = 'Главная';
$arDirProperties = array(
	'title' => 'Концертный тур музыкальной группы',
	'description' => 'Концертный тур музыкальной группы',
	'keywords' => 'Концертный тур музыкальной группы',
	'robots' => 'index, follow'
);
?>