<?global $arSite;?>
<?// copy your logo image to /logo.png (default)?>
<img class="header__logo" src="<?=SITE_DIR?>logo.png" alt="<?=$arSite["SITE_NAME"]?>" title="<?=$arSite["SITE_NAME"]?>">