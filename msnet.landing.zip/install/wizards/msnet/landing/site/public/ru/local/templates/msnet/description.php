<?
if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true)
	die();

$arTemplate = Array(
	'NAME' => 'Р С›РЎРѓР Р…Р С•Р Р†Р С•Р в„– РЎв‚¬Р В°Р В±Р В»Р С•Р Р…',
	'DESCRIPTION' => 'Р С›РЎРѓР Р…Р С•Р Р†Р С•Р в„– РЎв‚¬Р В°Р В±Р В»Р С•Р Р… Р Т‘Р В»РЎРЏ РЎРѓР В°Р в„–РЎвЂљР В°'
);
?>