<?
$MESS["C_BLOCK_TITLE"] = "Ближайшие концерты";
$MESS["C_BLOCK_BUY"] = "Купить билет";
?>