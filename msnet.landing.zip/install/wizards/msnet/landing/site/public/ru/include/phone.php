<? CModule::IncludeTemplateLangFile(__FILE__);

echo GetMessage('FOOTER_CONTACTS');
