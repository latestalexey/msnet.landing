<?php

$aMenuLinks = Array(
    Array(
        "О группе",
        "about",
        Array(),
        Array(
            "ANCHOR" => "about"
        ),
        ""
    ),
    Array(
        "Новости",
        "news",
        Array(),
        Array(
            "ANCHOR" => "news"
        ),
        ""
    ),
    Array(
        "Ближайшие концерты",
        "concerts",
        Array(),
        Array(
            "ANCHOR" => "concerts"
        ),
        ""
    ),
    Array(
        "Видео",
        "videos",
        Array(),
        Array(
            "ANCHOR" => "videos"
        ),
        ""
    )
);