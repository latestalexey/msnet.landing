<?
$sSectionName = "Р С’Р Р†РЎвЂљР С•РЎР‚Р С‘Р В·Р В°РЎвЂ Р С‘РЎРЏ";
$arDirProperties = array(

);
?>