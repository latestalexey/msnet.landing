<?
$MESS["REGISTERED_USERS"] = "Р вЂ”Р В°РЎР‚Р ВµР С–Р С‘РЎРѓРЎвЂљРЎР‚Р С‘РЎР‚Р С•Р Р†Р В°Р Р…Р Р…РЎвЂ№Р Вµ Р С—Р С•Р В»РЎРЉР В·Р С•Р Р†Р В°РЎвЂљР ВµР В»Р С‘";
$MESS["COMMUNITY_WIZARD_ADMINISTRATOR"] = "Р С’Р Т‘Р С?Р С‘Р Р…Р С‘РЎРѓРЎвЂљРЎР‚Р В°РЎвЂљР С•РЎР‚РЎвЂ№ Р С‘Р Р…РЎвЂћР С•РЎР‚Р С?Р В°РЎвЂ Р С‘Р С•Р Р…Р Р…Р С•Р С–Р С• Р С—Р С•РЎР‚РЎвЂљР В°Р В»Р В°";
$MESS["COMMUNITY_WIZARD_ADMINISTRATOR_DESCR"] = "Р СџР С•Р В»РЎРЉР В·Р С•Р Р†Р В°РЎвЂљР ВµР В»Р С‘ Р С?Р С•Р С–РЎС“РЎвЂљ Р С?Р С•Р Т‘Р ВµРЎР‚Р С‘РЎР‚Р С•Р Р†Р В°РЎвЂљРЎРЉ Р Р†РЎРѓР Вµ РЎР‚Р ВµРЎРѓРЎС“РЎР‚РЎРѓРЎвЂ№ РЎРѓР С•Р С•Р В±РЎвЂ°Р ВµРЎРѓРЎвЂљР Р†Р В°";
$MESS["TASK_WIZARD_CONTENT_EDITOR"] = "Р С™Р С•Р Р…РЎвЂљР ВµР Р…РЎвЂљ-РЎР‚Р ВµР Т‘Р В°Р С”РЎвЂљР С•РЎР‚РЎвЂ№";
$MESS["TASK_WIZARD_CONTENT_EDITOR_DESC"] = "Р В Р В°Р В·РЎР‚Р ВµРЎв‚¬Р ВµР Р…Р С• Р С‘Р В·Р С?Р ВµР Р…РЎРЏРЎвЂљРЎРЉ Р С‘Р Р…РЎвЂћР С•РЎР‚Р С?Р В°РЎвЂ Р С‘РЎР‹ Р Р† РЎРѓР Р†Р С•Р ВµР С? Р С—РЎР‚Р С•РЎвЂћР В°Р в„–Р В»Р Вµ. Р Р€Р С—РЎР‚Р В°Р Р†Р В»Р ВµР Р…Р С‘Р Вµ Р С”Р ВµРЎв‚¬Р ВµР С?";
$MESS["TASK_WIZARD_USER_NAME_1"] = "Р РЋР ВµРЎР‚Р С–Р ВµР в„–";
$MESS["TASK_WIZARD_USER_SURNAME_1"] = "Р ?Р Р†Р В°Р Р…Р С•Р Р†";
$MESS["TASK_WIZARD_USER_EMAIL_1"] = "ivanov@test.ru";
$MESS["TASK_WIZARD_USER_LOGIN_1"] = "ivan";
$MESS["TASK_WIZARD_USER_NAME_2"] = "Р ?Р Р†Р В°Р Р…";
$MESS["TASK_WIZARD_USER_SURNAME_2"] = "Р СџР ВµРЎвЂљРЎР‚Р С•Р Р†";
$MESS["TASK_WIZARD_USER_EMAIL_2"] = "petrov@test.ru";
$MESS["TASK_WIZARD_USER_LOGIN_2"] = "petrov";
$MESS["TASK_WIZARD_USER_NAME_3"] = "Р вЂ™Р С‘Р С”РЎвЂљР С•РЎР‚Р С‘РЎРЏ";
$MESS["TASK_WIZARD_USER_SURNAME_3"] = "Р В¤Р В°Р Т‘Р ВµР ВµР Р†Р В°";
$MESS["TASK_WIZARD_USER_EMAIL_3"] = "fadeeva@test.ru";
$MESS["TASK_WIZARD_USER_LOGIN_3"] = "viktoriya";
?>