<?
$MESS['MODULE_NAME'] = 'Адаптивный лендинг концертного тура';
$MESS['MODULE_DESCRIPTION'] = 'Сайт для концертного тура творческого коллектива';
$MESS['PARTNER_NAME'] = 'Медиасеть';
$MESS['PARTNER_URI'] = 'https://ms-net.ru';
?>